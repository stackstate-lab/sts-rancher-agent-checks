
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import json
import logging
import os
import time
import click
import yaml
from schematics.exceptions import DataError
from stackstate_etl.cli.cli_processor import CliProcessor
from stackstate_etl.model.instance import CliConfiguration


def run(conf, log_level, dry_run, repeat, work_dir, repeat_interval):
    logging.basicConfig(level=log_level.upper(
    ), format=u'%(asctime)s - %(name)s (%(lineno)s) - %(levelname)s: %(message)s', datefmt=u'%Y.%m.%d %H:%M:%S')
    if (work_dir != u'.'):
        os.chdir(work_dir)
        click.echo(u'Current working directory: {0}'.format(os.getcwd()))
    if repeat:
        click.echo(u'Running in repeat mode.')
        while True:
            _internal_run(conf, dry_run)
            click.echo(
                u''.join([u'Will repeat after ', u'{}'.format(repeat_interval), u' seconds.']))
            time.sleep(repeat_interval)
            click.echo(u'Repeating...')
    else:
        _internal_run(conf, dry_run)


def _internal_run(conf, dry_run):
    click.echo(u''.join([u'Loading configuration from ', u'{}'.format(conf)]))
    with open(conf) as f:
        dict_config = yaml.safe_load(f)
    try:
        configuration = CliConfiguration(dict_config)
        configuration.validate()
    except DataError as e:
        click.echo(u'Failed to load configuration:', err=True)
        click.echo(json.dumps(e.to_primitive(), indent=4), err=True)
        return 1
    if dry_run:
        click.echo(u'Running ETL sync in dry-run mode')
        result = CliProcessor(configuration).run(dry_run)
        click.echo(
            u'Discovered Components, Relations, Metrics, Events, Health information:')
        click.echo((u'-' * 80))
        for payload in result.payloads:
            click.echo(payload)
            click.echo((u'-' * 80))
    else:
        click.echo(u'Running ETL sync')
        result = CliProcessor(configuration).run()
    click.echo((u'-' * 80))
    click.echo(
        u''.join([u'Total Components = ', u'{}'.format(result.components), u'.']))
    click.echo(
        u''.join([u'Total Relations = ', u'{}'.format(result.relations), u'.']))
    click.echo(
        u''.join([u'Total Events = ', u'{}'.format(result.events), u'.']))
    click.echo(
        u''.join([u'Total Metrics = ', u'{}'.format(result.metrics), u'.']))
    click.echo(u''.join([u'Total Health Syncs = ',
               u'{}'.format(result.checks), u'.']))
    click.echo((u'-' * 80))
    click.echo(u'Done')


@click.command()
@click.option(u'-f', u'--conf', default=u'./conf.yaml', help=u'Configuration yaml file')
@click.option(u'--log-level', default=u'info', help=u'Log Level')
@click.option(u'--dry-run', is_flag=True, help=u'Dry run static topology sync')
@click.option(u'--repeat', is_flag=True, help=u'Runs topology sync as specified by the --repeat-interval')
@click.option(u'--work-dir', default=u'.', help=u'Set the current working directory')
@click.option(u'--repeat-interval', default=u'30', type=int, help=u'Repeat interval in seconds. Default 30.')
def cli(conf, log_level, dry_run, repeat, work_dir, repeat_interval):
    return run(conf, log_level, dry_run, repeat, work_dir, repeat_interval)


def main():
    return cli()
