
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
import json
from datetime import datetime
from typing import Any, Dict, List, Union
import pytz
from schematics import Model
from schematics.transforms import blacklist, wholelist
from schematics.types import BaseType, BooleanType, DictType, FloatType, ListType, ModelType, StringType
from schematics.types import TimestampType as DefaultTimestampType
from schematics.types import URLType


def to_json(item):
    if isinstance(item, list):
        dump_list = []
        for i in item:
            dump_list.append(i.to_primitive())
        return json.dumps(dump_list)
    return json.dumps(item.to_primitive())


class AnyType(BaseType):

    def __init__(self, **kwargs):
        super(AnyType, self).__init__(**kwargs)


class TimestampType(DefaultTimestampType):

    def to_primitive(self, value, context=None):
        value.astimezone(pytz.UTC)
        return int(round(value.timestamp()))


class ComponentType(Model):
    name = StringType(required=True)

    class Options(object):
        roles = {
            u'public': wholelist(),
        }


class Relation(Model):
    external_id = StringType(required=True, serialized_name=u'externalId')
    relation_type = ModelType(ComponentType, serialized_name=u'type')
    source_id = StringType(required=True, serialized_name=u'sourceId')
    target_id = StringType(required=True, serialized_name=u'targetId')
    properties = DictType(AnyType(), required=True, default={
        u'labels': [],
    }, serialized_name=u'data')

    class Options(object):
        roles = {
            u'public': wholelist(),
        }

    def set_type(self, name):
        if (self.relation_type is None):
            self.relation_type = ComponentType({
                u'name': name,
            })
        else:
            self.relation_type.name = name

    def get_type(self):
        if (self.relation_type is None):
            return u''
        else:
            return self.relation_type.name


class ComponentProperties(Model):
    name = StringType(required=True)
    layer = StringType(default=u'Unknown')
    domain = StringType(default=u'Unknown')
    environment = StringType(default=u'Unknown')
    labels = ListType(StringType(), default=[])
    identifiers = ListType(StringType(), default=[])
    custom_properties = DictType(AnyType(), default={

    })

    class Options(object):
        roles = {
            u'public': wholelist(),
        }

    def add_label(self, label):
        self.labels.append(label)

    def add_label_kv(self, key, value):
        self.labels.append(
            u''.join([u'{}'.format(key), u':', u'{}'.format(value)]))

    def add_identifier(self, identifier):
        if (identifier not in self.identifiers):
            self.identifiers.append(identifier)

    def update_properties(self, properties):
        self.custom_properties.update(properties)

    def add_property(self, name, value):
        self.custom_properties[name] = value

    def get_property(self, name):
        return self.custom_properties[name]

    def dedup_labels(self):
        labels = set(self.labels)
        self.labels = list(labels)
        identifiers = set(self.identifiers)
        self.identifiers = list(identifiers)


class Component(Model):
    uid = StringType(required=True, serialized_name=u'externalId')
    component_type = ModelType(ComponentType, serialized_name=u'type')
    properties = ModelType(ComponentProperties, required=True,
                           default=ComponentProperties(), serialized_name=u'data')
    relations = ListType(ModelType(Relation), default=[])
    mergeable = BooleanType(default=False)

    class Options(object):
        roles = {
            u'public': blacklist(u'relations', u'mergeable'),
        }

    def set_type(self, name):
        if (self.component_type is None):
            self.component_type = ComponentType({
                u'name': name,
            })
        else:
            self.component_type.name = name

    def get_type(self):
        return self.component_type.name

    def get_name(self):
        return self.properties.name

    def set_name(self, name):
        self.properties.name = name

    def merge(self, source):
        self.relations.extend(source.relations)
        self.properties.labels.extend(source.properties.labels)
        self.properties.identifiers.extend(source.properties.identifiers)
        self.properties.custom_properties.update(
            source.properties.custom_properties)


HEALTH_STATE_CHOICES = [u'CLEAR', u'DEVIATING', u'CRITICAL', u'UNKNOWN']


class HealthCheckState(Model):
    check_id = StringType(required=True, serialized_name=u'checkStateId')
    check_name = StringType(required=True, serialized_name=u'name')
    topo_identifier = StringType(
        required=True, serialized_name=u'topologyElementIdentifier')
    message = StringType(required=False)
    health = StringType(required=True, choices=HEALTH_STATE_CHOICES)

    class Options(object):
        roles = {
            u'public': wholelist(),
        }


class SourceLink(Model):
    title = StringType(required=True)
    url = URLType(fqdn=False, required=True)

    class Options(object):
        roles = {
            u'public': wholelist(),
        }


EVENT_CATEGORY_CHOICES = [u'Activities',
                          u'Alerts', u'Anomalies', u'Changes', u'Others']


class EventContext(Model):
    category = StringType(required=True, choices=EVENT_CATEGORY_CHOICES)
    data = DictType(AnyType, default={

    })
    element_identifiers = ListType(StringType, required=False, default=[])
    source = StringType(required=True, default=u'ETL')
    source_links = ListType(ModelType(SourceLink), required=False, default=[])

    class Options(object):
        roles = {
            u'public': wholelist(),
        }
        serialize_when_none = False


class Event(Model):
    context = ModelType(EventContext, required=True, default=EventContext())
    event_type = StringType(required=True)
    msg_title = StringType(required=True)
    msg_text = StringType(required=True)
    source_type_name = StringType(required=True, default=u'ETL')
    tags = ListType(StringType, required=False, default=[])
    timestamp = TimestampType(required=True)

    class Options(object):
        roles = {
            u'public': wholelist(),
        }


METRIC_TYPE_CHOICES = [u'gauge', u'count', u'monotonic_count',
                       u'rate', u'histogram', u'historate', u'increment', u'decrement']


class Metric(Model):
    name = StringType(required=True)
    timestamp = TimestampType(default=datetime.now(pytz.utc))
    metric_type = StringType(default=u'gauge', choices=METRIC_TYPE_CHOICES)
    value = FloatType(required=True)
    target_uid = StringType(required=True)
    tags = ListType(StringType, required=False, default=[])

    class Options(object):
        roles = {
            u'public': wholelist(),
        }
