
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from typing import List
from six import PY3
from stackstate_checks.base import AgentCheck, Health
from stackstate_etl.etl.etl_driver import ETLDriver
from stackstate_etl.model.factory import TopologyFactory
from stackstate_etl.model.instance import InstanceInfo
from stackstate_etl.model.stackstate import Component, HealthCheckState, Relation


class AgentProcessor(object):

    def __init__(self, instance, agent_check):
        self.agent_check = agent_check
        self.log = agent_check.log
        self.instance = instance
        self.factory = TopologyFactory()
        self.factory.log = self.log

    def process(self):
        self._process_etl()
        self._publish()

    def _process_etl(self):
        processor = ETLDriver(self.instance, self.factory,
                              self.agent_check.log)
        processor.process()

    def _publish(self):
        self.log.info(u''.join([u"Publishing '", u'{}'.format(
            len(self.factory.components.values())), u"' components"]))
        self.agent_check.start_snapshot()
        components = self.factory.components.values()
        for c in components:
            c.properties.dedup_labels()
            c_as_dict = c.properties.to_primitive()
            self.agent_check.component(self._encode_utf8(
                c.uid), self._encode_utf8(c.get_type()), c_as_dict)
        self.log.info(u''.join([u"Publishing '", u'{}'.format(
            len(self.factory.relations)), u"' relations"]))
        relations = self.factory.relations.values()
        for r in relations:
            self.agent_check.relation(self._encode_utf8(r.source_id), self._encode_utf8(
                r.target_id), self._encode_utf8(r.get_type()), r.properties)
        self.agent_check.stop_snapshot()
        self._publish_health()
        self._publish_events()
        self._publish_metrics()

    def _publish_health(self):
        self.log.info(u''.join([u"Synchronizing  '", u'{}'.format(
            len(self.factory.health)), u"' health states"]))
        health_instances = []
        if (len(self.factory.health) > 0):
            health_instances = self.factory.health.values()
        self.agent_check.health.start_snapshot()
        (deviating, clear, critical) = (0, 0, 0)
        for health in health_instances:
            health_value = health.health
            if (not isinstance(health_value, Health)):
                health_value = Health[health_value]
            if (health_value == Health.CLEAR):
                clear += 1
            elif (health_value == Health.CRITICAL):
                critical += 1
            elif (health_value == Health.DEVIATING):
                deviating += 1
            self.agent_check.health.check_state(
                health.check_id, health.check_name, health_value, health.topo_identifier, health.message)
        self.log.info(u''.join([u'Critical -> ', u'{}'.format(critical), u', Deviating -> ',
                      u'{}'.format(deviating), u', Clear -> ', u'{}'.format(clear)]))
        self.agent_check.health.stop_snapshot()

    def _publish_events(self):
        self.log.info(u''.join([u"Sending  '", u'{}'.format(
            len(self.factory.events)), u"' events"]))
        for event in self.factory.events:
            event_dict = event.to_primitive(role=u'public')
            self.agent_check.event(event_dict)

    def _publish_metrics(self):
        self.log.info(u''.join([u"Sending  '", u'{}'.format(
            len(self.factory.metrics)), u"' metrics"]))
        for metric in self.factory.metrics:
            metric_func = getattr(self.agent_check, metric.metric_type)
            metric_func(metric.name, metric.value,
                        tags=metric.tags, hostname=metric.target_uid)

    @staticmethod
    def _encode_utf8(string):
        if PY3:
            return string
        else:
            return string.encode(u'utf-8')
